from django.apps import AppConfig


class SocialAuthConfig(AppConfig):
    name = 'social_auth'
